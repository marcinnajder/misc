﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq.Expressions;
using System.Threading;

namespace RxSandbox
{
	/// <summary>
	/// Interaction logic for Window3.xaml
	/// </summary>
	public partial class Window3 : Window
	{
		public Window3()
		{
			this.InitializeComponent();
			
			// Insert code required on object creation below this point.
		}

	    private ExpressionInstanceVM _instance;
	    private void init(object sender, RoutedEventArgs e)
	    {
	        Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> func = (a, b) => a.Merge(b);

	        var definition = ExpressionDefinition.Create(func);
            _instance = new ExpressionInstanceVM(definition);

	        diagram.Diagram = _instance.Diagram;

	    }

	    private void add_marble(object sender, RoutedEventArgs e)
	    {
	        _instance.Inputs[0].Value = "one";
	        _instance.Inputs[0].OnNext.Execute(null);

            Thread.Sleep(100);

            _instance.Inputs[1].Value = "two";
            _instance.Inputs[1].OnNext.Execute(null);

            Thread.Sleep(100);

            _instance.Inputs[0].OnCompleted.Execute(null);

            Thread.Sleep(100);

            _instance.Inputs[1].Value = "tree";
            _instance.Inputs[1].OnNext.Execute(null);

            Thread.Sleep(100);

            _instance.Inputs[1].OnCompleted.Execute(null);



	    }
	}
}