﻿using System.Windows.Controls;

namespace RxSandbox
{
    public partial class InputControl : UserControl
    {
        public InputControl()
        {
            InitializeComponent();
        }
    }
}
