﻿using System.Windows;
using System.Windows.Controls;

namespace RxSandbox
{
    public partial class ExpressionControl : UserControl
    {
        public ExpressionControl()
        {
            InitializeComponent();            
        }
    }
}
