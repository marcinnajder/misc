using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Linq.Expressions;
using System.ComponentModel;
using System.Reactive.Subjects;
using System.Reflection;
using System.Threading;

namespace RxSandbox
{
    // todo: 

    // 2011.02 http://social.msdn.microsoft.com/Forums/en-US/rx/thread/1b554ca0-7e23-4603-8b00-7753acf08c83
    // Added ManySelect operator which is the comonadic bind operator and is similar to ContinueWith on tasks but can be used for streams.
    // Added GroupByUntil operator which is similar to GroupBy except that there�s a duration selector function to control the lifetime of each generated group.

    // 2011.04 http://social.msdn.microsoft.com/Forums/en-US/rx/thread/527002a3-18af-4eda-8e35-760ca0006b98    
    // - brak: Drain, Iterate, Prune
    // - jak dzialaja UT ? : Added absolute time scheduling to IScheduler  ,Created ReactiveTest base type with useful members , Added ReactiveAssert class with common asserts in Microsoft.Reactive.Testing
    // - rozwysowac sobie diagram klas System.Reactive.Concurrency
    

    internal static class LackingExtensions
    {
        public static U Let<T, U>(this T source, Func<T, U> f)
        {
            return f(source);
        }
    }

    public class StandardOperators : ExpressionAttributeBasedProvider
    {
        // vscl

        [Expression]
        public static ExpressionDefinition Vscl()
        {
            Func<IObservable<int>, IObservable<int>, IObservable<string>,
                IObservable<string>> expression
                    = (a, b, c) =>
                      (from v in a
                       where v > 5
                       select v.ToString("C")).Take(5).Merge(c);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = "vscl", Name = "vscl", Operator = null});
        }

        // combinators

        #region Combinators
                
        const string Combinators = "Combinators";

        [Expression]
        public static ExpressionDefinition Merge()
        {
            Expression<Func<IObservable<string>, IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b, c) => Observable.Merge(a, b, c);

            return ExpressionDefinition.Create(expression, 
                new ExpressionSettings {GroupPath = Combinators}) ;
        }

        [Expression]
        public static ExpressionDefinition Zip()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b) => a.Zip(b, (x, y) => x + " - " + y);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Combinators });
        }

        [Expression]
        public static ExpressionDefinition CombineLatest()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
              IObservable<string>>> expression
                  = (a, b) => a.CombineLatest(b, (x, y) => x + " - " + y);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Combinators });
        }

        [Expression]
        public static ExpressionDefinition Amb()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
              IObservable<string>>> expression
                  = (a, b) => a.Amb(b);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Combinators });
        }

        //[Expression]
        //public static ExpressionDefinition ForkJoin()
        //{
        //    Expression<Func<IObservable<string>, IObservable<string>,
        //        IObservable<string>>> expression
        //            = (a, b) => a.ForkJoin(b, (x, y) => x + " - " + y);

        //    return ExpressionDefinition.Create(expression,
        //        new ExpressionSettings { GroupPath = Combinators });
        //}

        [Expression]
        public static ExpressionDefinition Concat()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b) => a.Concat(b);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Combinators });
        }

        [Expression]
        public static ExpressionDefinition When()
        {
            Expression<Func<IObservable<string>, IObservable<string>, IObservable<string>,
                IObservable<string>, IObservable<string>>> expression
                    = (a, b, c, d) => Observable.When(
                        a.And(b).And(c).Then((x, y, z) => x + " - " + y + " - " + z),
                        a.And(d).Then((x, y) => x + " -- " + y));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Combinators });
        }

        #endregion

        #region linq

        const string Linq = "Linq";

        [Expression]
        public static ExpressionDefinition DefaultIfEmpty()
        {
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.DefaultIfEmpty("yo");

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition ElementAt()
        {            
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.ElementAt(4);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition ElementAtOrDefault()
        {
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.ElementAtOrDefault(4);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Contains()
        {
            Expression<Func<IObservable<string>, IObservable<bool>>> expression
                = (a) => a.Contains("aaa");

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Take()
        {                        
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.Take(4);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition TakeWhile()
        {
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.TakeWhile(i => i.Length < 3);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition TakeUntil()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b) => a.TakeUntil(b);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }


        [Expression]
        public static ExpressionDefinition TakeLast()
        {
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.TakeLast(3);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Skip()
        {
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.Skip(4);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition SkipWhile()
        {
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.SkipWhile(i => i.Length < 3);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition SkipUntil()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b) => a.SkipUntil(b);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition SkipLast()
        {
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.SkipLast(3);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }


        [Expression]
        public static ExpressionDefinition Where()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = (a) => a.Where(i => i.Length % 2 == 0);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Select()
        {
            Expression<Func<IObservable<string>,
                IObservable<int>>> expression
                    = (a) => a.Select(i => i.Length);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition SelectMany()
        {
            Expression<Func<IObservable<long>, IObservable<long>>> expression
                = a => a.SelectMany(v => Observable.Interval(TimeSpan.FromMilliseconds(1000)).Select(_ => v).Take((int)v));


            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Aggregate()
        {
            Expression<Func<IObservable<string>,
                IObservable<int>>> expression
                    = (a) => a.Aggregate(0, (acc, v) => acc + v.Length);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Count()
        {
            Expression<Func<IObservable<string>,
                IObservable<int>>> expression
                    = a => a.Count();

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Sum()
        {
            Expression<Func<IObservable<int>,
                IObservable<int>>> expression
                    = a => a.Sum();

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Max()
        {
            Expression<Func<IObservable<int>,
                IObservable<int>>> expression
                    = a => a.Max();

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition MaxBy()
        {            
            
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.MaxBy(i => i.Length).Select( l => string.Join(",",l));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.MaxBy<string,string>(null,null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Min()
        {
            Expression<Func<IObservable<int>,
                IObservable<int>>> expression
                    = a => a.Min();

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition MinBy()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.MinBy(i => i.Length).Select(l => string.Join(",", l));


            var @operator = ReflectionHelper.GetMethod(
                () => Observable.MinBy<string, string>(null, null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Linq });
        }


        [Expression]
        public static ExpressionDefinition Average()
        {
            Expression<Func<IObservable<double>,
                IObservable<double>>> expression
                    = a => a.Average();

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition All()
        {
            Expression<Func<IObservable<string>,
                IObservable<bool>>> expression
                    = a => a.All(i => i.Length < 3);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        [Expression]
        public static ExpressionDefinition Any()
        {
            Expression<Func<IObservable<string>,
                IObservable<bool>>> expression
                    = a => a.Any(i => i.Length < 3);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq});
        }


        [Expression]
        public static ExpressionDefinition GroupBy()
        {
            string code =
@"
from s in a
group s by s.Length
  into gr
  from ss in gr
  select ""Key: "" + gr.Key + ""  Value: "" + ss;
";
            Expression<Func<IObservable<string>, IObservable<string>>> expression = a =>
              from s in a
              group s by s.Length
                  into gr
                  from ss in gr
                  select "Key: " + gr.Key + "  Value: " + ss;

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.GroupBy<string, string>(null, _ => _));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code,
                                         GroupPath = Linq});
        }


        [Expression]
        public static ExpressionDefinition Join()
        {
            string code =
@"
 from m in man
 join f in female on leaving.Where(i => i == m) equals leaving.Where(i => i == f)                  
 select m + "" "" + f
";
         
            Expression<Func<IObservable<string>, IObservable<string>, IObservable<string>, IObservable<string>>> expression = 
                (man, female, leaving) =>
                  from m in man
                  join f in female on leaving.Where(i => i == m) equals leaving.Where(i => i == f)                  
                  select m + " , " + f;

            //var @operator = ReflectionHelper.GetMethod(
            //    () => Observable.Join(null, _ => _));
            
            return ExpressionDefinition.Create(expression,
                new ExpressionSettings
                {
                    Name = "Join",
                    CodeSample = code,
                    GroupPath = Linq
                });
        }

        [Expression]
        public static ExpressionDefinition GroupJoin()
        {
            
            string code =
@"
 from m in man
 join f in female on leaving.Where(i => i == m) equals leaving.Where(i => i == f)
   into m_fs
 from f2 in m_fs.Select( (s,index) => index + "". "" + s )
 select m + "" , "" + f2;
";

            Expression<Func<IObservable<string>, IObservable<string>, IObservable<string>, IObservable<string>>> expression =
                (man, female, leaving) =>
                  from m in man
                  join f in female on leaving.Where(i => i == m) equals leaving.Where(i => i == f)
                    into m_fs
                  from f2 in m_fs.Select( (s,index) => index + ". " + s )
                  select m + " , " + f2;

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.GroupJoin<string, string, string, string, string>(null, null, null, null, null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings
                {
                    Operator = @operator,
                    CodeSample = code,
                    GroupPath = Linq
                });
        }


        // sa analogiczne: ToArray, ToDictionary, ToLoopup
        [Expression]
        public static ExpressionDefinition ToList()
        {                                    
            Expression<Func<IObservable<string>, IObservable<string>>> expression =
                a => a.ToList().Select(l => string.Join(",", l));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.ToList<string>(null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq, Operator = @operator });
        }

        [Expression]
        public static ExpressionDefinition SequenceEqual()
        {
            Expression<Func<IObservable<string>, IObservable<string>, IObservable<bool>>> expression =
                (a, b) => a.SequenceEqual(b);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Linq });
        }

        #endregion

        #region Exceptions
        
        const string Exceptions = "Exceptions";


        [Expression]
        public static ExpressionDefinition Catch()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b) => a.Catch(b);
            
            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Exceptions });
        }

        [Expression]
        public static ExpressionDefinition OnErrorResumeNext()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b) => a.OnErrorResumeNext(b);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Exceptions });
        }

        [Expression]
        public static ExpressionDefinition Retry()
        {
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                = a => a
                    .SelectMany(v => string.IsNullOrEmpty(v) ? Observable.Throw<string>(new Exception()) : Observable.Return(v))
                    .Retry(3);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Exceptions });
        }

        #endregion

        #region rx

        const string Rx = "Rx";

        [Expression]
        public static ExpressionDefinition Delay()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = (a) => a.Delay(TimeSpan.FromSeconds(2));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Rx });
        }

        [Expression]
        public static ExpressionDefinition Throttle()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = (a) => a.Throttle(TimeSpan.FromSeconds(2));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Rx });
        }

        const string Sample = Rx + "/Sample";

        [Expression]
        public static ExpressionDefinition Sample_WithTime()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = (a) => a.Sample(TimeSpan.FromSeconds(2));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Sample, Name = MethodBase.GetCurrentMethod().Name });
        }

        [Expression]
        public static ExpressionDefinition Sample_WithSampler()
        {
            Expression<Func<IObservable<string>,IObservable<string>,
                IObservable<string>>> expression
                    = (a,b) => a.Sample(b);

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Sample, Name = MethodBase.GetCurrentMethod().Name });
        }

        [Expression]
        public static ExpressionDefinition Distinct()
        {                            
            Expression<Func<IObservable<string>, IObservable<string>>> expression
                    = (a) => a.Distinct();

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Rx });
        }

        [Expression]
        public static ExpressionDefinition DistinctUntilChanged()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = (a) => a.DistinctUntilChanged();

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Rx });
        }


        [Expression]
        public static ExpressionDefinition Scan()
        {
            Expression<Func<IObservable<string>,
                IObservable<int>>> expression
                    = (a) => a.Scan(0, (acc, v) => acc + v.Length);

            return ExpressionDefinition.Create(expression,
                 new ExpressionSettings { GroupPath = Rx });
        }




        const string Buffer = Rx + "/Buffer";

        [Expression]
        public static ExpressionDefinition Buffer_WithCount()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.Buffer(3).
                        Select(i => string.Join(",", i.ToArray()));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Buffer<string>(null, 3));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Buffer, Name = MethodBase.GetCurrentMethod().Name });
        }

        [Expression]
        public static ExpressionDefinition Buffer_WithTime()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.Buffer(TimeSpan.FromSeconds(3)).
                        Select(i => string.Join(",", i.ToArray()));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Buffer<string>(null, TimeSpan.FromSeconds(3)));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Buffer, Name = MethodBase.GetCurrentMethod().Name });
        }

        [Expression]
        public static ExpressionDefinition Buffer_WithTimeOrCount()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.Buffer(TimeSpan.FromSeconds(3), 3).
                        Select(i => string.Join(",", i.ToArray()));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Buffer<string>(null, TimeSpan.FromSeconds(3), 3));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Buffer, Name = MethodBase.GetCurrentMethod().Name });
        }



        [Expression]
        public static ExpressionDefinition Switch()
        {
            Expression<Func<IObservable<double>,
                IObservable<double>>> expression
                    = a => a.Select(i => Observable.Return(i).Delay(TimeSpan.FromSeconds(i))).Switch();

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Switch<int>((IObservable<IObservable<int>>)null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Rx });
        }

        [Expression]
        public static ExpressionDefinition Timer()
        {
            Expression<Func<IObservable<int>,
                IObservable<long>>> expression
                    = a => a.SelectMany(i => Observable.Timer(TimeSpan.FromSeconds(i)));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Timer(TimeSpan.FromSeconds(10)));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Rx });
        }

        [Expression]
        public static ExpressionDefinition Timeout()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.Timeout(TimeSpan.FromSeconds(3));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { GroupPath = Rx });
        }

        [Expression]
        public static ExpressionDefinition Interval()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => Observable.Interval(TimeSpan.FromSeconds(1))
                        .Select(_ => DateTime.Now.ToLongTimeString())
                        .TakeUntil(a);

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Interval(TimeSpan.FromSeconds(1)));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Rx });
        }

        //[Expression]
        //public static ExpressionDefinition Let()
        //{
        //    Expression<Func<IObservable<string>,
        //        IObservable<string>>> expression
        //            = a => a.Let(o => o.Zip(o, (x, y) => x + " - " + y));

        //    return ExpressionDefinition.Create(expression,
        //        new ExpressionSettings { GroupPath = Rx });
        //}

//        [Expression]        
//        public static ExpressionDefinition Prune()
//        {
//            string code =
//@"
//a.Prune().Let(o =>
//{
//    IDisposable disposable = null;
//
//    connect_disconnect                            
//        .Subscribe(connect =>
//        {
//            if (connect)
//                disposable = (o as IConnectableObservable<string>).Connect();
//            else
//                disposable.Dispose();
//        });
//
//    return subscribeMe.SelectMany(name => o, (name, value) => name + "": "" + value);
//});
//";
//            var r = new ReplaySubject<string>(2);    

//            Func<IObservable<string>, IObservable<bool>, IObservable<string>, IObservable<string>>
//                expression = (a, connect_disconnect, subscribeMe) =>
//                    a.Prune().Let(o =>
//                    {
//                        IDisposable disposable = null;

//                        connect_disconnect
//                            .Subscribe(connect =>
//                            {
//                                if (connect)
//                                    disposable = (o as IConnectableObservable<string>).Connect();
//                                else
//                                    disposable.Dispose();
//                            });

//                        return subscribeMe.SelectMany(name => o, (name, value) => name + ": " + value);
//                    });

//            var @operator = ReflectionHelper.GetMethod(
//                () => Observable.Prune<string,string>(null,null));

//            return ExpressionDefinition.Create(expression,
//                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Rx });
//        }

        [Expression]
        public static ExpressionDefinition Publish()
        {
            string code =
  @"
a.Publish().Let(o =>
{
    IDisposable disposable = null;

    connect_disconnect                            
        .Subscribe(connect =>
        {
            if (connect)
                disposable = (o as IConnectableObservable<string>).Connect();
            else
                disposable.Dispose();
        });

    return subscribeMe.SelectMany(name => o, (name, value) => name + "": "" + value);
});
";
            
            Func<IObservable<string>, IObservable<bool>, IObservable<string>, IObservable<string>>
                expression = (a, connect_disconnect, subscribeMe) =>
                    a.Publish().Let(o =>
                    {
                        IDisposable disposable = null;

                        connect_disconnect
                            .Subscribe(connect =>
                            {
                                if (connect)
                                    disposable = (o as IConnectableObservable<string>).Connect();
                                else
                                    disposable.Dispose();
                            });

                        return subscribeMe.SelectMany(name => o, (name, value) => name + ": " + value);
                    });

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Publish<string>(null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Rx });
        }

        [Expression]
        public static ExpressionDefinition Replay()
        {
            string code =
  @"
a.Replay().Let(o =>
{
    IDisposable disposable = null;

    connect_disconnect                            
        .Subscribe(connect =>
        {
            if (connect)
                disposable = (o as IConnectableObservable<string>).Connect();
            else
                disposable.Dispose();
        });

    return subscribeMe.SelectMany(name => o, (name, value) => name + "": "" + value);
});
";
            Func<IObservable<string>, IObservable<bool>, IObservable<string>, IObservable<string>>
                expression = (a, connect_disconnect, subscribeMe) =>
                    a.Replay().Let(o =>
                    {
                        IDisposable disposable = null;

                        connect_disconnect
                            .Subscribe(connect =>
                            {
                                if (connect)
                                    disposable = (o as IConnectableObservable<string>).Connect();
                                else
                                    disposable.Dispose();
                            });

                        return subscribeMe.SelectMany(name => o, (name, value) => name + ": " + value);
                    });

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Replay<string>(null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Rx });
        }

    

        [Expression]
        public static ExpressionDefinition RefCount()
        {            
            string code =
@"
var r = new ReplaySubject<string>(); 

a.Multicast(r).RefCount().Let(o =>
    subscribe.SelectMany(
        name => o.TakeUntil(unsubscribe.Where(n => n == name)),
        (name, value) => name + "" : "" + value));
";

            var r = new ReplaySubject<string>(); 

            Func<IObservable<string>, IObservable<string>, IObservable<string>, IObservable<string>>
                expression = (a, subscribe, unsubscribe) =>
                    a.Multicast(r).RefCount().Let(o =>
                        subscribe.SelectMany(
                            name => o.TakeUntil(unsubscribe.Where(n => n == name)),
                            (name, value) => name + " : " + value));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.RefCount<string>(null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Rx });
            
        }



//        [Expression]
//        public static ExpressionDefinition Iterate()
//        {
//            string code =
//@"
//var iter = Observable.Iterate( () => new[]
//  {
//      values1.Select(v => (object) v),
//      Observable.Return(10).Select(v => (object) v),
//      Observable.Range(20, 10).Select(v => (object) v),
//      values2.Select(v => (object) v),
//  });
//return startWhenOnCompleted.Concat(iter.Select(u => ""));
//";
//            Func<IObservable<string>, IObservable<string>, IObservable<string>, IObservable<string>> expression
//                = (startWhenOnCompleted, values1, values2) =>
//                  {
//                      var iter = Observable.Iterate( () => new[]
//                        {
//                            values1.Select(v => (object) v),
//                            Observable.Return(10).Select(v => (object) v),
//                            Observable.Range(20, 10).Select(v => (object) v),
//                            values2.Select(v => (object) v),
//                        });

//                      return startWhenOnCompleted.Concat(iter.Select(u => ""));                      
//                  };
       
//            var @operator = ReflectionHelper.GetMethod(
//                () => Observable.Iterate(() => null));

//            return ExpressionDefinition.Create(expression,
//                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Rx });
//        }

        //private static IEnumerable<IObservable<int>> Iterate_(IObserver<object> observer)
        //{
        //    observer.OnNext("Range...");
        //    yield return Observable.Range(1,10);
        //    observer.OnNext("Return...");
        //    yield  return Observable.Return(5);            
        //}


        //[Expression]
        //public static ExpressionDefinition Drain()
        //{
        //    Expression<Func<IObservable<string>, IObservable<string>, IObservable<string>,
        //        IObservable<string>>> expression
        //        = (a, d1, d2) => a.Drain(s => s == "d1" ? d1.Select(x => new Unit()) :
        //                                        s == "d2" ? d2.Select(x => new Unit()) : Observable.Return(new Unit()))
        //                           .Select(_ => "");

        //    var @operator = ReflectionHelper.GetMethod(() => Observable.Drain<string>(null, null));

        //    return ExpressionDefinition.Create(expression,
        //        new ExpressionSettings { Operator = @operator, GroupPath = Rx });
        //}


        const string Window = Rx + "/Window";

        [Expression]
        public static ExpressionDefinition Window_WithClosingSelector()
        {
            // to przeciazenie stosujemy kiedy jest tylko jedno otwarte okno w danym czasie
            // sygnal zamyka dane okno i otwiera nowe 
            Expression<Func<IObservable<string>, IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b1, b2) => a.Window(() => b1.Take(1).Concat(b2).Skip(1))
                        .SelectMany(i => i.Select((ii, index) => index + " " + ii));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Window<string, string>((IObservable<string>)null, (IObservable<string>)null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Window, Name = MethodBase.GetCurrentMethod().Name});
        }

        [Expression]
        public static ExpressionDefinition Window_WithCount()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.Window(3)
                        .SelectMany(i => i.Select((ii, index) => index + " " + ii));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Window<string>(null, 3));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Window, Name = MethodBase.GetCurrentMethod().Name });
        }

        [Expression]
        public static ExpressionDefinition Window_WithTime()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.Window(TimeSpan.FromSeconds(3))
                        .SelectMany(i => i.Select((ii, index) => index + " " + ii));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Window<string>(null, TimeSpan.FromSeconds(3)));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Window, Name = MethodBase.GetCurrentMethod().Name });
        }

        [Expression]
        public static ExpressionDefinition Window_WithTimeOrCount()
        {
            Expression<Func<IObservable<string>,
                IObservable<string>>> expression
                    = a => a.Window(TimeSpan.FromSeconds(3), 3)
                        .SelectMany(i => i.Select((ii, index) => index + " " + ii));

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.Window<string>(null, TimeSpan.FromSeconds(3), 3));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Window, Name = MethodBase.GetCurrentMethod().Name });
        }

        //[Expression]
        //public static ExpressionDefinition Expand()
        //{
        //    Expression<Func<IObservable<int>, IObservable<int>>> expression =
        //        a => a.Expand(v => v == 0 ? Observable.Empty<int>() : Observable.Return(v - 1).Delay(TimeSpan.FromSeconds(v)));

        //    var @operator = ReflectionHelper.GetMethod(
        //        () => Observable.Expand<string>(null, null));


        //    return ExpressionDefinition.Create(expression,
        //        new ExpressionSettings { Operator = @operator, GroupPath = Rx });
        //}

        [Expression]
        public static ExpressionDefinition IgnoreElements()
        {
            Expression<Func<IObservable<string>,IObservable<string>>> expression =
                a => a.IgnoreElements();

            var @operator = ReflectionHelper.GetMethod(
                () => Observable.IgnoreElements<string>(null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, GroupPath = Rx});
        }

        #endregion

        #region Statemets

        private const string Statemets = "Statemets";

        [Expression]
        public static ExpressionDefinition While()
        {
            string code =
@"
bool w = true;
@while.Subscribe(v => w = v);
return Observable.While(() => w, source.TakeWhile( x => x != ""_"" ));
";
            Func<IObservable<bool>, IObservable<string>, IObservable<string>> expression
                = (condition, a) =>
                {
                    bool w = true;
                    condition.Subscribe(v => w = v);
                    return Observable.While(() => w, a.TakeWhile( x => x != "_" ));
                };

            var @operator = ReflectionHelper.GetMethod(
               () => Observable.While<long>(null,null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Statemets });
        }

        [Expression]
        public static ExpressionDefinition DoWhile()
        {
            string code =
@"
bool w = false;
@while.Subscribe(v => w = v);
return Observable.DoWhile(source.TakeWhile( x => x != ""_"" ), () => w);
";
            Func<IObservable<bool>, IObservable<string>, IObservable<string>> expression
                = (condition, a) =>
                {
                    bool w = false;
                    condition.Subscribe(v => w = v);
                    return Observable.DoWhile(a.TakeWhile(x => x != "_"), () => w);
                };

            var @operator = ReflectionHelper.GetMethod(
               () => Observable.DoWhile<long>(null, null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Statemets });
        }

        [Expression]
        public static ExpressionDefinition If()
        {
            string code =
@"
bool w = true;
condition.Subscribe(v => w = v);
return Observable
    .If(() => w, a.TakeWhile(x => x != ""_""), a.Select(x=>x.ToUpper()).TakeWhile(x => x != ""_""))
    .Repeat();
";
            Func<IObservable<bool>, IObservable<string>, IObservable<string>> expression
                = (condition, a) =>
                {
                    bool w = true;
                    condition.Subscribe(v => w = v);
                    return Observable
                        .If(() => w, a.TakeWhile(x => x != "_"), a.Select(x=>x.ToUpper()).TakeWhile(x => x != "_"))
                        .Repeat();
                };

            var @operator = ReflectionHelper.GetMethod(
               () => Observable.If<long>(null,null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Statemets });
            
        }

        [Expression]
        public static ExpressionDefinition Case()
        {
            string code =
@"
    string w = ""a"";
    condition.Subscribe(v => w = v);
    return Observable
        .Case(() => w, new Dictionary<string, IObservable<string>>
        {
            {""a"", a.TakeWhile(x => x != ""_"")},
            {""b"", a.Select(x => x.ToUpper()).TakeWhile(x => x != ""_"")},
            {""c"",  a.SelectMany( x => Observable.Repeat(x, 2)).TakeWhile(x => x != ""_"")) },
        })                        
        .Repeat();
";
            Func<IObservable<string>, IObservable<string>, IObservable<string>> expression
                = (condition, a) =>
                {
                    string w = "a";
                    condition.Subscribe(v => w = v);
                    return Observable
                        .Case(() => w, new Dictionary<string, IObservable<string>>
                            {
                                {"a", a.TakeWhile(x => x != "_")},
                                {"b", a.Select(x => x.ToUpper()).TakeWhile(x => x != "_")},
                                {"c", a.SelectMany( x => Observable.Repeat(x, 2)).TakeWhile(x => x != "_")  },
                            })                        
                        .Repeat();
                };

            var @operator = ReflectionHelper.GetMethod(
               () => Observable.Case<string,string>(null, null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Statemets });

        }

        [Expression]
        public static ExpressionDefinition For()
        {
            string code =
@"
Observable.For(new[] {1,2,3,4},
    i => a.SelectMany( x => Observable.Repeat(x, i)).TakeWhile(x => x != ""_""));
";
            Func<IObservable<string>, IObservable<string>> expression
                = a => Observable.For(new[] {1,2,3,4},
                    i => a.SelectMany( x => Observable.Repeat(x, i)).TakeWhile(x => x != "_"));

            var @operator = ReflectionHelper.GetMethod(
               () => Observable.For<string, string>(null, null));

            return ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, CodeSample = code, GroupPath = Statemets });
        }

        #endregion

    }



    static class Ex
    {
        public static IObservable<T> MyFirst<T>(this IObservable<T> source)
        {
            return source
                .Aggregate(
                    new { First = true, Item = default(T) },
                    (a, n) => new { First = false, Item = a.First ? n : a.Item })
                .Where(i => !i.First)
                .Select(i => i.Item);
        }
        public static T Trace<T>(this T value)
        {
            Console.WriteLine(value);
            return value;
        }


    }

    public class CustomExpressions : ExpressionAttributeBasedProvider
    {
        [Expression]
        public static ExpressionDefinition Merge()
        {
            Expression<Action> temp = () => Observable.Merge(new IObservable<string>[0]);
            var @operator = (temp.Body as MethodCallExpression).Method;

            Func<IObservable<string>, IObservable<string>, IObservable<string>,
                IObservable<string>> expression
                    = (a, b, c) => Observable.Merge(a, b, c);

            return ExpressionDefinition.Create(expression, new ExpressionSettings
                { Operator = @operator });
        }

        [Expression]
        public static ExpressionDefinition IncrementalSearch()
        {
            Func<IObservable<string>, IObservable<Person>, IObservable<Person>> expression
                    = (codeChanged, webServiceCall) =>
                          {
                            var q =
                                from code in codeChanged
                                from x in Observable.Return(Unit.Default).Delay(TimeSpan.FromSeconds(4)).TakeUntil(codeChanged)
                                from result in webServiceCall.TakeUntil(codeChanged)
                                select result;

                              return q;
                          };

            return ExpressionDefinition.Create(expression, new ExpressionSettings
               {
                   Name = "Incremental find",
                   Description = @"Send the code of the person you are looking for, "
                        + "after four seconds (if you don't send new code again) web service "
                        + "will be called. The result won't be returned if new code is provided "
                        + "in the meantime.",                   
               });
        }
        [Expression]
        public static ExpressionDefinition IncrementalSearch2()
        {
            Expression<Func<IObservable<string>, IObservable<Person>, IObservable<Person>>> expression
                    = (codeChanged, webServiceCall) =>
                        codeChanged
                            .Throttle(TimeSpan.FromSeconds(4))
                            .Select(code => webServiceCall)
                            .Switch();

            return ExpressionDefinition.Create(expression, new ExpressionSettings
            {
                Name = "Incremental find 2",
                Description = @"Send the code of the person you are looking for, "
                     + "after four seconds (if you don't send new code again) web service "
                     + "will be called. The result won't be returned if new code is provided "
                     + "in the meantime.",
            });
        }


    }

    [TypeConverter(typeof(PersonConverter))]
    public class Person
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public class PersonConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (sourceType == typeof (string))
                return true;
            return base.CanConvertFrom(context, sourceType);
        }
        
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is string)
            {
                string[] v = ((string)value).Split(new[] { ',' });
                return new Person {Code = v[0], Name = v[1]};
            }
            return base.ConvertFrom(context, culture, value);
        }
        
        public override object ConvertTo(ITypeDescriptorContext context,
           CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == typeof (string))
            {
                var person = value as Person;
                return person.Code + "," + person.Name;
            }                
            return base.ConvertTo(context, culture, value, destinationType);
        }
    }

    [AttributeUsage(AttributeTargets.Method,AllowMultiple = false, Inherited = true)]
    public class ExpressionAttribute : Attribute
    {
        
    }

    public interface IExpressionProvider
    {
        IEnumerable<ExpressionDefinition> GetExpressions();
    }

    public abstract class ExpressionAttributeBasedProvider : IExpressionProvider
    {
        public IEnumerable<ExpressionDefinition> GetExpressions()
        {
            var q =
                from m in this.GetType().GetMethods()
                let attr = Attribute.GetCustomAttribute(m, typeof(ExpressionAttribute)) as ExpressionAttribute
                where attr != null
                select m.Invoke(null, null) as ExpressionDefinition;
            return q.ToList();
        }
    }
}