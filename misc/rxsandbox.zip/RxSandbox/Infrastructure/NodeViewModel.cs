﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RxSandbox
{
    public class NodeViewModel
    {
        public bool IsExpanded { get; set; }
        public string Name { get; set; }  
        public bool IsGroup { get; set; }
        
        public List<NodeViewModel> Subgroups { get; private set; }
        public List<NodeViewModel> Expressions { get; private set; }

        public ExpressionDefinition Definition { get; private set; }

        public IEnumerable<NodeViewModel> Nodes { get { return Subgroups.Concat(Expressions); } }
        
        internal NodeViewModel()
        {
            Subgroups = new List<NodeViewModel>();
            Expressions = new List<NodeViewModel>();
        }

        public static NodeViewModel Create(IExpressionProvider expressionProvider)
        {
            var groups = new Dictionary<string, NodeViewModel>();
            var root = new NodeViewModel {Name = expressionProvider.GetType().Name, IsGroup = true};

            foreach (var expression in expressionProvider.GetExpressions())
            {
                var expressionNode = new NodeViewModel {IsGroup = false, Definition = expression, 
                    Name = expression.Name + (expression.IsExperimental ? " (E)" : "") };

                if (string.IsNullOrEmpty(expression.GroupPath))
                {
                    root.Expressions.Add(expressionNode);
                }
                else
                {
                    var gr = CreateGroupPath(expression.GroupPath, groups);
                    gr.Expressions.Add(expressionNode);                    
                    AddIfNotContains(root, groups[expression.GroupPath.Split(new[] { '/' }, StringSplitOptions.None)[0]]);
                }
            }

            return root;            
        }

        private static NodeViewModel CreateGroupPath(string path, IDictionary<string,NodeViewModel> groups)
        {
            NodeViewModel group = null;

            if (groups.TryGetValue(path, out group))
                return group;

            var parts = path.Split(new[] { '/' }, StringSplitOptions.None);

            if (parts.Length == 0)
            {
                var gr = new NodeViewModel { IsGroup = true, Name = "" };
                groups.Add(path, gr);
                return gr;
            }
            if (parts.Length == 1)
            {
                var gr = new NodeViewModel { IsGroup = true, Name = parts[0] };
                groups.Add(path, gr);
                return gr;
            }
            else
            {
                var parent = CreateGroupPath(string.Join("/", parts.Take(parts.Length - 1).ToArray()), groups);
                var gr = new NodeViewModel { IsGroup = true, Name = parts.Last() };
                groups.Add(path, gr);
                AddIfNotContains(parent,gr);
                return gr;
            }            
        }

        private static void AddIfNotContains(NodeViewModel parent, NodeViewModel child)
        {
            if (!parent.Subgroups.Contains(child))
                parent.Subgroups.Add(child);
        }
    }

    
}