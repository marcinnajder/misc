﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System;
using System.Diagnostics;
using RxSandbox.Properties;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;

namespace RxSandbox
{
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
            Init2();
            DataContext = this;
        }

        private void PopulateExpressionNodes(IEnumerable<ExpressionDefinition> expressions,
            TreeViewItem node)
        {            
            foreach (var o in expressions)
            {
                var item = new TreeViewItem { Header = o.Name, Tag = o };
                item.MouseDoubleClick += item_MouseDoubleClick;
                node.Items.Add(item);
            }
        }

        private void item_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var definition = ((sender as TreeViewItem).Tag as ExpressionDefinition);
            if (definition == null)
                return;

            var instanceVM = new ExpressionInstanceVM(definition);            
            var control = new ExpressionControl {DataContext = instanceVM};
            var item = new TabItem
            {
                Tag = definition.Name,
                Header = definition.Name,
                Content = control
            };
            
            EventHandler closeHandler = null;
            closeHandler = (o, ea) =>
                               {
                                   tabControl.Items.Remove(item);
                                   instanceVM.CloseRequested -= closeHandler;
                               };
            instanceVM.CloseRequested += closeHandler;

            tabControl.Items.Add(item);
            item.Focus();     
        }


        protected override void OnClosed(EventArgs e)
        {
            foreach (TabItem tabItem in tabControl.Items)
                ((tabItem.Content as ExpressionControl).DataContext as ExpressionInstanceVM).CleanUp();

            base.OnClosed(e);
        }


        private void Init2()
        {
            var assemblies = new[] {Assembly.GetExecutingAssembly().FullName,
                Settings.Default.ExtensionsAssembly}.Distinct();

            var q =
                from assemblyName in assemblies
                where !string.IsNullOrEmpty(assemblyName)
                let assembly = Assembly.Load(assemblyName)
                where assembly != null
                from t in assembly.GetTypes()
                where typeof(IExpressionProvider).IsAssignableFrom(t) && t.GetConstructor(new Type[0]) != null && !t.IsAbstract
                let instance = Activator.CreateInstance(t) as IExpressionProvider
                select NodeViewModel.Create(instance);

            try
            {
                q = q.ToArray();
            }
            catch (Exception exception)
            {
                if (exception is TargetInvocationException)
                {
                    exception = exception.InnerException;
                }
                MessageBox.Show(exception.Message, "Loading extension assembly failed.");
            }

            var root = new NodeViewModel {Name = "Operators", IsGroup = true, IsExpanded = true};
            foreach (var n in q)
            {
                n.IsExpanded = true; 
                root.Subgroups.Add(n);
            }

            treeView.ItemsSource = new [] {root};
        }
    }
}
