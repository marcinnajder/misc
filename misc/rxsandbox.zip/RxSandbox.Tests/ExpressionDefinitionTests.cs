﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reactive.Linq;
using NUnit.Framework;
using System.Threading;
using System.Reflection;

namespace RxSandbox.Tests
{
    [TestFixture]
    public class ExpressionDefinitionTests
    {
        [Test]
        public void FromExpressionTest()
        {            
            Expression<Func<IObservable<string>, IObservable<string>,
              IObservable<string>>> expression
                  = (a, b) => a.Zip(b, (x, y) => x + " - " + y);

            var definition = ExpressionDefinition.Create(expression);
            
            Assert.AreEqual(definition.Name, "Zip");
            Assert.IsNotEmpty(definition.Description);
            Assert.AreEqual(definition.ExpressionString, expression.ToString());
            Assert.IsNotNull(definition.Diagram);
            Assert.AreEqual(definition.Diagram.Id, "Zip");
        }

        [Test]
        public void FromExpressionWithExplicitOperatorTest()
        {
            
            Expression<Action> temp = () => Observable.Zip<string, string, string>(null, (IObservable<string>) null, null);
            var @operator = (temp.Body as MethodCallExpression).Method;

            Expression<Func<IObservable<string>, IObservable<string>,
              IObservable<string>>> expression
                  = (a, b) => a.Zip(b, (x, y) => x + " - " + y).Select( s => s);

            var definition = ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator });
            
            Assert.AreEqual(definition.Name, "Zip");
            Assert.IsNotEmpty(definition.Description);
            Assert.AreEqual(definition.ExpressionString, expression.ToString());
            Assert.IsNotNull(definition.Diagram);
            Assert.AreEqual(definition.Diagram.Id, "Zip");
        }

        [Test]
        public void FromExpressionWithExplicitOperatorAndNameAndDiagramIdTest()
        {
            Expression<Action> temp = () => Observable.Zip<string, string, string>(null, (IObservable<string>) null, null);
            var @operator = (temp.Body as MethodCallExpression).Method;

            Expression<Func<IObservable<string>, IObservable<string>,
              IObservable<string>>> expression
                  = (a, b) => a.Zip(b, (x, y) => x + " - " + y).Select(s => s);

            var definition = ExpressionDefinition.Create(expression,
                new ExpressionSettings { Operator = @operator, Name = "Zip (2)", DiagramId = "Zip"});

            Assert.AreEqual(definition.Name, "Zip (2)");
            Assert.IsNotEmpty(definition.Description);
            Assert.AreEqual(definition.ExpressionString, expression.ToString());
            Assert.IsNotNull(definition.Diagram);
            Assert.AreEqual(definition.Diagram.Id, "Zip");
        }

        [Test]
        public void FromExpressionWithExplicitDiagramTest()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b) => a.Zip(b, (x, y) => x + " - " + y);

            var diagram = new Diagram();
            var definition = ExpressionDefinition.Create(expression,
                new ExpressionSettings { Diagram = diagram});

            Assert.AreEqual(definition.Name, "Zip");
            Assert.IsNotEmpty(definition.Description);
            Assert.AreEqual(definition.ExpressionString, expression.ToString());
            Assert.IsNotNull(definition.Diagram);
            Assert.AreEqual(definition.Diagram, diagram);
        }


        [Test]
        public void FromDelegateTest()
        {
            Func<IObservable<string>, IObservable<string>,
              IObservable<string>> expression
                  = (a, b) => a.Zip(b, (x, y) => x + " - " + y);

            var definition = ExpressionDefinition.Create(expression);

            Assert.IsNull(definition.Name);
            Assert.IsNull(definition.Description);
            Assert.IsNull(definition.ExpressionString);
            Assert.IsNull(definition.Diagram);
        }

        [Test]
        public void FromDelegateWithExplicitOperatorTest()
        {
            Expression<Action> temp = () => Observable.Zip<string, string, string>(null, (IObservable<string>)null, null);
            var @operator = (temp.Body as MethodCallExpression).Method;

            Func<IObservable<string>, IObservable<string>,
              IObservable<string>> expression
                  = (a, b) => a.Zip(b, (x, y) => x + " - " + y);

            var definition = ExpressionDefinition.Create(expression, 
                new ExpressionSettings {Operator = @operator});

            Assert.AreEqual(definition.Name, "Zip");
            Assert.IsNotEmpty(definition.Description);
            Assert.IsNull(definition.ExpressionString);
            Assert.IsNotNull(definition.Diagram);
            Assert.AreEqual(definition.Diagram.Id, "Zip");
        }
    }
}
