﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reactive.Linq;
using NUnit.Framework;
using System.Threading;
using System.Reflection;

namespace RxSandbox.Tests
{

    [TestFixture]
    public class SampleDiagram
    {
        private DiagramContainer _container;

        [TestFixtureSetUp]
        public void SetUp()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);
            _container = new DiagramContainer();
        }

        #region combinators

        [Test]
        public void Merge()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Merge();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");
                var c = instance.GetInput("c");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                c.OnNext2(gen.Next());
                a.OnCompleted2();
                b.OnNext2(gen.Next());
                b.OnCompleted2();
                c.OnNext2(gen.Next());
                c.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }


        [Test]
        public void Zip()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Zip();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnCompleted2();
                b.OnNext2(gen.Next());
                b.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void CombineLatest()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.CombineLatest();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnCompleted2();
                b.OnNext2(gen.Next());
                b.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Amb()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Amb();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                b.OnCompleted2();
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        //[Test]
        //public void ForkJoin()
        //{
        //    Console.WriteLine(MethodBase.GetCurrentMethod().Name);

        //    var gen = new InputGenerator();
        //    var definition = StandardOperators.ForkJoin();

        //    using (var instance = ExpressionInstance.Create(definition))
        //    {
        //        var a = instance.GetInput("a");
        //        var b = instance.GetInput("b");

        //        a.OnNext2(gen.Next());
        //        a.OnNext2(gen.Next());
        //        b.OnNext2(gen.Next());
        //        a.OnCompleted2();
        //        b.OnNext2(gen.Next());                
        //        b.OnCompleted2();

        //        AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
        //    }
        //}

        [Test]
        public void Concat()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Concat();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnCompleted2();
                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                b.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void When()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.When();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");
                var c = instance.GetInput("c");
                var d = instance.GetInput("d");

                b.OnNext2("b");
                c.OnNext2("c");
                d.OnNext2("d");
                a.OnNext2("a");

                a.OnNext2("a");
                d.OnNext2("d");

                a.OnNext2("a");
                b.OnNext2("b");
                c.OnNext2("c");

                a.OnCompleted2();
                b.OnCompleted2();
                c.OnCompleted2();
                d.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        #endregion

        #region linq

        [Test]
        public void DefaultIfEmpty()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.DefaultIfEmpty();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void ElementAt()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.ElementAt();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }


        [Test]
        public void ElementAtOrDefault()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.ElementAtOrDefault();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());            
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Contains()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Contains();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aaaa");
                a.OnNext2("aaaaa");                
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }


        [Test]
        public void Take()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Take();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void TakeWhile()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.TakeWhile();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aaaa");
                a.OnNext2("aaaaa");
                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void TakeUntil()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.TakeUntil();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                b.OnCompleted2();
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void TakeLast()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.TakeLast();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
               
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());                
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Skip()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Skip();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void SkipWhile()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.SkipWhile();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aaaa");
                a.OnNext2("aaaaa");
                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void SkipUntil()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.SkipUntil();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                b.OnCompleted2();
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void SkipLast()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.SkipLast();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Where()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Where();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aaaa");
                a.OnNext2("aaaaa");
                a.OnNext2("aaaaaa");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }


        [Test]
        public void Select()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Select();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aaaa");
                a.OnNext2("aaaaa");
                a.OnNext2("aaaaaa");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void SelectMany()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.SelectMany();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("2");
                a.OnCompleted2();

                Thread.Sleep(3000);

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Aggregate()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Aggregate();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(100);
                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aa");
                a.OnNext2("a");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Count()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Count();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Sum()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Sum();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("2");
                a.OnNext2("123");
                a.OnNext2("55");
                a.OnNext2("-50");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Max()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Max();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("2");
                a.OnNext2("123");
                a.OnNext2("55");
                a.OnNext2("-50");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void MaxBy()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.MaxBy();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("aa");
                a.OnNext2("aaaa");
                a.OnNext2("a");
                a.OnNext2("aaa");
                a.OnNext2("bbbb");               
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Min()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Min();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("2");
                a.OnNext2("123");
                a.OnNext2("55");
                a.OnNext2("-50");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void MinBy()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.MinBy();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("aa");
                a.OnNext2("aaaa");
                a.OnNext2("a");
                a.OnNext2("aaa");
                a.OnNext2("b");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Average()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Average();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("2");
                a.OnNext2("123");
                a.OnNext2("55");
                a.OnNext2("-50");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void All()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.All();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aaaa");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Any()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Any();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("aaaa");
                a.OnNext2("aaa");
                a.OnNext2("aa");
                a.OnNext2("a");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void GroupBy()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.GroupBy();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aaa");
                a.OnNext2("aa");
                a.OnNext2("a");
                a.OnNext2("a");
                a.OnNext2("a");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }


        [Test]
        public void Join()
        {            
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Join();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var man = instance.GetInput("man");
                var female = instance.GetInput("female");
                var leaving = instance.GetInput("leaving");

                man.OnNext2("Joel");
                man.OnNext2("Arni");
                female.OnNext2("Maria");
                leaving.OnNext2("Joel");
                female.OnNext2("Toni");
                
                man.OnCompleted2();
                female.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void GroupJoin()
        {            
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.GroupJoin();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var man = instance.GetInput("man");
                var female = instance.GetInput("female");
                var leaving = instance.GetInput("leaving");

                man.OnNext2("Joel");
                man.OnNext2("Arni");
                female.OnNext2("Maria");
                leaving.OnNext2("Joel");
                female.OnNext2("Toni");

                man.OnCompleted2();
                female.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void ToList()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.ToList();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void SequenceEqual()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.SequenceEqual();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                a.OnNext2("a");
                b.OnNext2("a");
                a.OnNext2("b");
                a.OnNext2("c");
                a.OnCompleted2();                
                b.OnNext2("b");
                b.OnNext2("c");
                b.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        #endregion

        #region exceptions

        [Test]
        public void Catch()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Catch();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnError2();
                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void OnErrorResumeNext()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.OnErrorResumeNext();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();
                b.OnNext2(gen.Next());
                b.OnNext2(gen.Next());

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Retry()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Retry();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("b");
                a.OnNext2("");
                a.OnNext2("c");
                a.OnNext2("d");
                a.OnNext2("");
                a.OnNext2("e");
                a.OnNext2("f");
                a.OnNext2("");

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        #endregion

        #region rx
        
        [Test]
        public void Delay()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Delay();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(DateTime.Now.ToLongTimeString());
                a.OnNext2(DateTime.Now.ToLongTimeString());
                a.OnCompleted2();
                Thread.Sleep(3000);

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Throttle()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Throttle();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(DateTime.Now.ToLongTimeString());
                a.OnNext2(DateTime.Now.ToLongTimeString());
                Thread.Sleep(3000);
                a.OnNext2(DateTime.Now.ToLongTimeString());
                a.OnNext2(DateTime.Now.ToLongTimeString());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Sample_WithTime()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Sample_WithTime();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(DateTime.Now.ToLongTimeString());
                a.OnNext2(DateTime.Now.ToLongTimeString());
                Thread.Sleep(3000);
                a.OnNext2(DateTime.Now.ToLongTimeString());
                a.OnNext2(DateTime.Now.ToLongTimeString());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Sample_WithSampler()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Sample_WithSampler();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b = instance.GetInput("b");

                a.OnNext2(gen .Next());
                a.OnNext2(gen .Next());
                a.OnNext2(gen .Next());
                b.OnNext2("yo");
                a.OnNext2(gen .Next());
                a.OnNext2(gen .Next());
                a.OnNext2(gen .Next());
                b.OnNext2("yo2");
                a.OnNext2(gen .Next());
                a.OnNext2(gen .Next());
                b.OnCompleted2();
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Distinct()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Distinct();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("b");
                a.OnNext2("b");
                a.OnNext2("c");
                a.OnNext2("a");
                a.OnNext2("b");
                a.OnNext2("c");
                a.OnNext2("d");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void DistinctUntilChanged()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.DistinctUntilChanged();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("b");
                a.OnNext2("b");
                a.OnNext2("b");
                a.OnNext2("c");
                a.OnNext2("c");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Scan()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Scan();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2("a");
                a.OnNext2("aa");
                a.OnNext2("aaa");
                a.OnNext2("aa");
                a.OnNext2("a");
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Buffer_WithCount()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Buffer_WithCount();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(100);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Buffer_WithTime()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Buffer_WithTime();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(100);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                Thread.Sleep(3000);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Buffer_WithTimeOrCount()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Buffer_WithTimeOrCount();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(100);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                Thread.Sleep(4000);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Switch()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Switch();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(1);

                a.OnNext2("1");
                Thread.Sleep(500);
                a.OnNext2("1");
                Thread.Sleep(500);
                a.OnNext2("1");
                Thread.Sleep(500);
                a.OnNext2("3");
                Thread.Sleep(4000);
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Timer()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Timer();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(1);

                a.OnNext2("2");
                a.OnNext2("1");
                a.OnCompleted2();
                Thread.Sleep(2000);

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Timeout()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Timeout();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(1000);
                a.OnNext2(DateTime.Now.ToLongTimeString());
                Thread.Sleep(1000);
                a.OnNext2(DateTime.Now.ToLongTimeString());
                Thread.Sleep(4000);

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Interval()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Interval();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(3000);
                a.OnNext2(gen.Next());

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        //[Test]
        //public void Let()
        //{
        //    Console.WriteLine(MethodBase.GetCurrentMethod().Name);

        //    var gen = new InputGenerator();
        //    var definition = StandardOperators.Let();

        //    using (var instance = ExpressionInstance.Create(definition))
        //    {
        //        var a = instance.GetInput("a");

        //        a.OnNext2(gen.Next());
        //        a.OnNext2(gen.Next());
        //        a.OnNext2(gen.Next());
        //        a.OnNext2(gen.Next());
        //        a.OnCompleted2();

        //        AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
        //    }
        //}

        [Test]
        public void Publish()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Publish();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var connect_disconnect = instance.GetInput("connect_disconnect");
                var subscribeMe = instance.GetInput("subscribeMe");

                a.OnNext2(gen.Next());
                connect_disconnect.OnNext2("true");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                subscribeMe.OnNext2("Arni");
                a.OnNext2(gen.Next());
                subscribeMe.OnNext2("Joel");
                a.OnNext2(gen.Next());
                connect_disconnect.OnNext2("false");
                a.OnNext2(gen.Next());
                connect_disconnect.OnNext2("true");
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        //[Test]
        //public void Prune()
        //{
        //    Console.WriteLine(MethodBase.GetCurrentMethod().Name);

        //    var gen = new InputGenerator();
        //    var definition = StandardOperators.Prune();

        //    using (var instance = ExpressionInstance.Create(definition))
        //    {
        //        var a = instance.GetInput("a");
        //        var connect_disconnect = instance.GetInput("connect_disconnect");
        //        var subscribeMe = instance.GetInput("subscribeMe");

        //        a.OnNext2(gen.Next());
        //        connect_disconnect.OnNext2("true");
        //        a.OnNext2(gen.Next());
        //        a.OnNext2(gen.Next());
        //        subscribeMe.OnNext2("Arni");
        //        a.OnNext2(gen.Next());
        //        subscribeMe.OnNext2("Joel");
        //        a.OnNext2(gen.Next());
        //        connect_disconnect.OnNext2("false");
        //        a.OnNext2(gen.Next());
        //        connect_disconnect.OnNext2("true");
        //        a.OnNext2(gen.Next());
        //        a.OnCompleted2();

        //        AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
        //    }
        //}

        [Test]
        public void Replay()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Replay();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var connect_disconnect = instance.GetInput("connect_disconnect");
                var subscribeMe = instance.GetInput("subscribeMe");

                a.OnNext2(gen.Next());
                connect_disconnect.OnNext2("true");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                subscribeMe.OnNext2("Arni");
                a.OnNext2(gen.Next());
                subscribeMe.OnNext2("Joel");
                a.OnNext2(gen.Next());
                connect_disconnect.OnNext2("false");
                a.OnNext2(gen.Next());
                connect_disconnect.OnNext2("true");
                a.OnNext2(gen.Next());
                subscribeMe.OnNext2("Michael");

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        //[Test]
        //public void Multicast()
        //{
        //    Console.WriteLine(MethodBase.GetCurrentMethod().Name);

        //    var gen = new InputGenerator();
        //    var definition = StandardOperators.Multicast();

        //    using (var instance = ExpressionInstance.Create(definition))
        //    {
        //        var a = instance.GetInput("a");
        //        var connect_disconnect = instance.GetInput("connect_disconnect");
        //        var subscribeMe = instance.GetInput("subscribeMe");

        //        a.OnNext2(gen.Next());
        //        connect_disconnect.OnNext2("true");
        //        a.OnNext2(gen.Next());
        //        a.OnNext2(gen.Next());
        //        subscribeMe.OnNext2("Arni");
        //        a.OnNext2(gen.Next());
        //        subscribeMe.OnNext2("Joel");
        //        a.OnNext2(gen.Next());
        //        connect_disconnect.OnNext2("false");
        //        a.OnNext2(gen.Next());
        //        connect_disconnect.OnNext2("true");
        //        a.OnNext2(gen.Next());
        //        a.OnCompleted2();

        //        AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
        //    }
        //}

        [Test]
        public void RefCount()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.RefCount();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var subscribe = instance.GetInput("subscribe");
                var unsubscribe = instance.GetInput("unsubscribe");

                a.OnNext2(gen.Next());
                subscribe.OnNext2("Arni");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                unsubscribe.OnNext2("Arni");
                a.OnNext2(gen.Next());
                subscribe.OnNext2("Joel");
                subscribe.OnNext2("Michael");
                a.OnNext2(gen.Next());

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        //[Test]
        //public void Iterate()
        //{
        //    Console.WriteLine(MethodBase.GetCurrentMethod().Name);

        //    var gen = new InputGenerator();
        //    var definition = StandardOperators.Iterate();

        //    using (var instance = ExpressionInstance.Create(definition))
        //    {
        //        var startWhenOnCompleted = instance.GetInput("startWhenOnCompleted");
        //        var values1 = instance.GetInput("values1");
        //        var values2 = instance.GetInput("values2");

        //        startWhenOnCompleted.OnCompleted2();
        //        values2.OnNext2(gen.Next());
        //        values2.OnNext2(gen.Next());
        //        values1.OnNext2(gen.Next());
        //        values1.OnNext2(gen.Next());
        //        values1.OnNext2(gen.Next());
        //        values1.OnCompleted2();
        //        values2.OnNext2(gen.Next());
        //        values2.OnNext2(gen.Next()); 
        //        values2.OnCompleted2();

        //        AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
        //    }
        //}

        //[Test]
        //public void Drain()
        //{
        //    Console.WriteLine(MethodBase.GetCurrentMethod().Name);

        //    var gen = new InputGenerator();
        //    var definition = StandardOperators.Drain();

        //    using (var instance = ExpressionInstance.Create(definition))
        //    {
        //        var a = instance.GetInput("a");
        //        var d1 = instance.GetInput("d1");
        //        var d2 = instance.GetInput("d2");

        //        a.OnNext2(gen.Next());         
        //        a.OnNext2("d1");                
        //        a.OnNext2("d2");
        //        a.OnNext2(gen.Next());
        //        d1.OnNext2(gen.Next());
        //        d1.OnNext2(gen.Next());
        //        a.OnCompleted();
        //        d1.OnCompleted();
        //        d2.OnNext2(gen.Next());
        //        d2.OnCompleted();

        //        AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
        //    }
        //}

        [Test]
        public void Window_WithClosingSelector()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Window_WithClosingSelector();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");
                var b1 = instance.GetInput("b1");
                var b2 = instance.GetInput("b2");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());

                b1.OnNext2("b1 - 1");
                a.OnNext2(gen.Next());
                b2.OnNext2("b2 - 1");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                b2.OnNext2("b2 - 2");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());

                b1.OnNext2("b1 - 2");
                b2.OnNext2("b2 - 3");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());

           
                a.OnCompleted();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Window_WithCount()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Window_WithCount();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(100);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Window_WithTime()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Window_WithTime();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(100);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                Thread.Sleep(3000);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Window_WithTimeOrCount()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Window_WithTimeOrCount();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                Thread.Sleep(100);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                Thread.Sleep(4000);
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        //[Test]
        //public void Expand()
        //{
        //    Console.WriteLine(MethodBase.GetCurrentMethod().Name);

        //    var gen = new InputGenerator();
        //    var definition = StandardOperators.Expand();

        //    using (var instance = ExpressionInstance.Create(definition))
        //    {
        //        var a = instance.GetInput("a");

        //        Thread.Sleep(100);
        //        a.OnNext2("2");
        //        Thread.Sleep(2500);

        //        AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
        //    }
        //}

        [Test]
        public void IgnoreElements()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.IgnoreElements();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnCompleted2();

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        #endregion

        #region statemets

        [Test]
        public void While()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.While();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var condition = instance.GetInput("condition");
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                condition.OnNext2("false");
                a.OnNext2(gen.Next());
                a.OnNext2("_");

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void DoWhile()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.DoWhile();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var condition = instance.GetInput("condition");
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                condition.OnNext2("true");
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                condition.OnNext2("false");
                a.OnNext2(gen.Next());
                a.OnNext2("_");

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void If()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.If();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var condition = instance.GetInput("condition");
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                condition.OnNext2("false");
                a.OnNext2(gen.Next());
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2("_");

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void Case()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.Case();

            using (var instance = ExpressionInstance.Create(definition))
            {
                var condition = instance.GetInput("condition");
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                condition.OnNext2("b");
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                condition.OnNext2("c");
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2(gen.Next());
                a.OnNext2("_");

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        [Test]
        public void For()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);

            var gen = new InputGenerator();
            var definition = StandardOperators.For();

            using (var instance = ExpressionInstance.Create(definition))
            {                
                var a = instance.GetInput("a");

                a.OnNext2(gen.Next());
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2("_");
                a.OnNext2(gen.Next());
                a.OnNext2("_");

                AddDiagram(MethodBase.GetCurrentMethod().Name, instance.Diagram);
            }
        }

        #endregion

        private void AddDiagram(string id, Diagram diagram)
        {
            
            diagram.Id = id;
            Console.WriteLine(XmlSerializationHelper.ToXml(diagram));
            _container.Diagrams.Add(diagram);
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            Console.WriteLine(MethodBase.GetCurrentMethod().Name);
            string xml = XmlSerializationHelper.ToXml(_container);
            Console.WriteLine(xml);
        }
    }

    internal static class Extensions
    {
        internal static void OnNext2(this ObservableInput input, string value)
        {
            input.OnNext(value);
            Thread.Sleep(100);
        }
        internal static void OnError2(this ObservableInput input)
        {
            input.OnError(new Exception());
            Thread.Sleep(100);
        }
        internal static void OnCompleted2(this ObservableInput input)
        {
            input.OnCompleted();
            Thread.Sleep(100);
        }

        internal static ObservableInput GetInput(this ExpressionInstance instance, string inputName)
        {
            return instance.Inputs.First(g => g.Name == inputName);
        }
    }

    public class InputGenerator
    {
        private static readonly char[] _chars = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'w', 'y', 'z' };
        private int i = 0;

        public string Next()
        {
            return _chars[i++].ToString();
        }
    }
}
