﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using NUnit.Framework;
using System.Threading;

namespace RxSandbox.Tests
{
    [TestFixture]
    public class NodeViewModeTest
    {
        private class Provider : IExpressionProvider
        {
            private IEnumerable<ExpressionDefinition> _expressions;

            public static Provider Create(params string[] groups)
            {
                Action action = () => { };
                Delegate @delegate = action;

                return new Provider
                           {
                               _expressions = groups
                                .Select(gr => gr.Split('-'))
                                .Select(
                                    gr => ExpressionDefinition.Create(@delegate,
                                    new ExpressionSettings { GroupPath = gr[0], Name = gr[1] }))
                           };
            }

            public IEnumerable<ExpressionDefinition> GetExpressions()
            {
                return _expressions;
            }
        }

        [Test]
        public void RootNodeTest()
        {
            var provider = Provider.Create();
            var node = NodeViewModel.Create(provider);

            Assert.IsNotNull(node);
            Assert.AreEqual(node.Name, provider.GetType().Name);
            Assert.IsTrue(node.IsGroup);
            Assert.IsNotNull(node.Subgroups);
            Assert.AreEqual(node.Subgroups.Count, 0);
            Assert.IsNotNull(node.Expressions);
            Assert.AreEqual(node.Expressions.Count, 0);
            
            Console.WriteLine(node.NodeToString());
        }

        [Test]
        public void NoGroupsTest()
        {
            var provider = Provider.Create("-a", "-b", "-c");
            var node = NodeViewModel.Create(provider);
            
            Assert.AreEqual(node.Subgroups.Count, 0);
            Assert.AreEqual(node.Expressions.Count, 3);

            AssertExpression(node.Expressions[0], "a");
            AssertExpression(node.Expressions[1], "b");
            AssertExpression(node.Expressions[2], "c");

            Console.WriteLine(node.NodeToString());
        }

        [Test]
        public void OneLevelGroupTest()
        {
            var provider = Provider.Create("A-a", "B-b", "-c");
            var node = NodeViewModel.Create(provider);
     
            Assert.AreEqual(node.Subgroups.Count, 2);        
            Assert.AreEqual(node.Expressions.Count, 1);

            AssertGroup(node.Subgroups[0], "A");
            AssertExpression(node.Subgroups[0].Expressions[0], "a");
            AssertGroup(node.Subgroups[1], "B");
            AssertExpression(node.Subgroups[1].Expressions[0], "b");
            AssertExpression(node.Expressions[0], "c");
            
            Console.WriteLine(node.NodeToString());
        }

        [Test]
        public void TwoLevelGroupTest()
        {
            var provider = Provider.Create("A/A2-a", "B-b", "-c");
            var node = NodeViewModel.Create(provider);

            Assert.AreEqual(node.Subgroups.Count, 2);
            Assert.AreEqual(node.Expressions.Count, 1);

            AssertGroup(node.Subgroups[0], "A");
            AssertGroup(node.Subgroups[0].Subgroups[0], "A2");
            AssertExpression(node.Subgroups[0].Subgroups[0].Expressions[0], "a");
            AssertGroup(node.Subgroups[1], "B");
            AssertExpression(node.Subgroups[1].Expressions[0], "b");
            AssertExpression(node.Expressions[0], "c");

            Console.WriteLine(node.NodeToString());
        }

        [Test]
        public void TwoLevelWithEmptyGroupNameTest()
        {
            var provider = Provider.Create("A/-a", "B-b", "-c");
            var node = NodeViewModel.Create(provider);

            Assert.AreEqual(node.Subgroups.Count, 2);
            Assert.AreEqual(node.Expressions.Count, 1);

            AssertGroup(node.Subgroups[0], "A");
            AssertGroup(node.Subgroups[0].Subgroups[0], "");
            AssertExpression(node.Subgroups[0].Subgroups[0].Expressions[0], "a");
            AssertGroup(node.Subgroups[1], "B");
            AssertExpression(node.Subgroups[1].Expressions[0], "b");
            AssertExpression(node.Expressions[0], "c");

            Console.WriteLine(node.NodeToString());
        }

        [Test]
        public void TwoGroupsWithCommonRootParentTest()
        {
            var provider = Provider.Create("A/A2-a", "A/B-b", "-c");
            var node = NodeViewModel.Create(provider);

            Assert.AreEqual(node.Subgroups.Count, 1);
            Assert.AreEqual(node.Expressions.Count, 1);

            AssertGroup(node.Subgroups[0], "A");
            AssertGroup(node.Subgroups[0].Subgroups[0], "A2");
            AssertExpression(node.Subgroups[0].Subgroups[0].Expressions[0], "a");
            AssertGroup(node.Subgroups[0].Subgroups[1], "B");
            AssertExpression(node.Subgroups[0].Subgroups[1].Expressions[0], "b");            
            AssertExpression(node.Expressions[0], "c");

            Console.WriteLine(node.NodeToString());
        }

        [Test]
        public void TwoGroupsWithCommonParentTest()
        {
            var provider = Provider.Create("A/A2-a", "A/A2/B-b", "-c");
            var node = NodeViewModel.Create(provider);

            Assert.AreEqual(node.Subgroups.Count, 1);
            Assert.AreEqual(node.Expressions.Count, 1);

            AssertGroup(node.Subgroups[0], "A");
            AssertGroup(node.Subgroups[0].Subgroups[0], "A2");
            AssertExpression(node.Subgroups[0].Subgroups[0].Expressions[0], "a");
            AssertGroup(node.Subgroups[0].Subgroups[0].Subgroups[0], "B");
            AssertExpression(node.Subgroups[0].Subgroups[0].Subgroups[0].Expressions[0], "b");
            AssertExpression(node.Expressions[0], "c");

            Console.WriteLine(node.NodeToString());
        }


        private static void AssertGroup(NodeViewModel group, string name)
        {
            Assert.IsTrue(group.IsGroup);
            Assert.AreEqual(group.Name, name);
            Assert.IsNull(group.Definition);
            Assert.IsNotNull(group.Subgroups);
            Assert.IsNotNull(group.Expressions);
        }
        private static void AssertExpression(NodeViewModel expression, string name)
        {
            Assert.IsFalse(expression.IsGroup);
            Assert.AreEqual(expression.Name, name);
            Assert.IsNotNull(expression.Definition);
            Assert.IsNotNull(expression.Subgroups);
            Assert.IsNotNull(expression.Expressions);
        }
    }

    internal static class NodeViewModeExtensions
    {
        public static string NodeToString(this NodeViewModel node)
        {
            string result = node.Name;

            var gr = string.Join(",", node.Subgroups.Select(n => n.NodeToString()).ToArray());
            if (!string.IsNullOrEmpty(gr))
                result += "(" + gr + ")";

            gr = string.Join(",", node.Expressions.Select(n => n.NodeToString()).ToArray());
            if (!string.IsNullOrEmpty(gr))
                result += "[" + gr + "]";

            return result;
        }
    }
}
