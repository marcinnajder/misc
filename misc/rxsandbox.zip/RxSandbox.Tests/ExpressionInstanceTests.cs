﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reactive.Linq;
using NUnit.Framework;
using System.Threading;

namespace RxSandbox.Tests
{
    [TestFixture]
    public class ExpressionInstanceTests
    {
        [Test]
        public void FromExpessionTest()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                 = (a, b) => a.Zip(b, (x, y) => x + " - " + y);

            var definition = ExpressionDefinition.Create(expression);
            var instance = ExpressionInstance.Create(definition);

            Assert.IsNotNull(instance);
            Assert.AreEqual(definition, instance.Definition);
            Assert.IsNotNull(instance.Inputs);
            Assert.AreEqual(2, instance.Inputs.Count);
            Assert.IsNotNull(instance.Output);

            Assert.IsNull(instance["c"]);
            Assert.IsNotNull(instance["a"]);
            Assert.AreSame( instance["a"], instance.Inputs[0]);
            Assert.IsNotNull(instance["b"]);
            Assert.AreSame(instance["b"], instance.Inputs[1]);
        }

        [Test]
        public void FromDelegateTest()
        {
            Func<IObservable<string>, IObservable<string>,
                IObservable<string>> expression
                 = (a, b) => a.Zip(b, (x, y) => x + " - " + y);

            var definition = ExpressionDefinition.Create(expression);
            var instance = ExpressionInstance.Create(definition);

            Assert.IsNotNull(instance);
            Assert.AreEqual(definition, instance.Definition);
            Assert.IsNotNull(instance.Inputs);
            Assert.AreEqual(2, instance.Inputs.Count);
            Assert.IsNotNull(instance.Output);

            Assert.IsNull(instance["c"]);
            Assert.IsNotNull(instance["a"]);
            Assert.AreSame(instance["a"], instance.Inputs[0]);
            Assert.IsNotNull(instance["b"]);
            Assert.AreSame(instance["b"], instance.Inputs[1]);
        }




        [Test]
        public void OnNextOnInputTest()
        {
            var history = new List<string>();
            var aGenerator = new ObservableInput<string>();
            aGenerator.ObservableStr.Subscribe(history.Add);
            
            Assert.IsTrue(aGenerator.IsActive);
            Assert.AreEqual( typeof(string),  aGenerator.Type);
            
            (aGenerator as ObservableInput).OnNext("yo1");
            (aGenerator as ObservableInput).OnNext("yo2");
            (aGenerator).OnNext("yo3");

            Assert.IsNotEmpty(history);
            Assert.AreEqual(3, history.Count);
            Assert.IsTrue(history.SequenceEqual(new[] { "yo1", "yo2", "yo3" }));
        }

        [Test]
        public void OnNextOnInputWithConverterTest()
        {
            var history = new List<string>();
            var aGenerator = new ObservableInput<int>();
            aGenerator.ObservableStr.Subscribe(history.Add);

            Assert.IsTrue(aGenerator.IsActive);
            Assert.AreEqual(typeof(int), aGenerator.Type);

            aGenerator.OnNext("1");
            aGenerator.OnNext("2");
            aGenerator.OnNext(3);

            Assert.IsNotEmpty(history);
            Assert.AreEqual(3, history.Count);
            Assert.IsTrue(history.SequenceEqual(new[] { "1", "2", "3" }));
        }

        [Test]
        public void OnCompletedOnInputTest()
        {
            bool onCompletedExecuted = false;
            var aGenerator = new ObservableInput<string>();
            aGenerator.ObservableStr.Subscribe((a) => { }, () => onCompletedExecuted = true);

            (aGenerator as ObservableInput).OnNext("yo1");
            (aGenerator as ObservableInput).OnNext("yo2");
            (aGenerator).OnCompleted();

            Assert.IsFalse(aGenerator.IsActive);
            Assert.IsTrue(onCompletedExecuted);
        }

        [Test]
        public void OnErrorOnInputTest()
        {
            Exception onErrorException = null;
            var aGenerator = new ObservableInput<string>();
            aGenerator.ObservableStr.Subscribe((a) => { }, (ex) => onErrorException = ex);

            (aGenerator as ObservableInput).OnNext("yo1");
            (aGenerator as ObservableInput).OnNext("yo2");
            var exception = new Exception();
            (aGenerator).OnError(exception);

            Assert.IsFalse(aGenerator.IsActive);
            Assert.IsNotNull(onErrorException);
            Assert.AreSame(exception, onErrorException);
        }



        [Test]
        public void UsingExpressionInstance()
        {
            Expression<Func<IObservable<string>, IObservable<string>, IObservable<string>,
               IObservable<string>>> expression
                   = (a, b, c) => Observable.Merge(a, b, c);

            ExpressionDefinition definition = ExpressionDefinition.Create(expression);
            ExpressionInstance instance = ExpressionInstance.Create(definition);

            // using non-generic type 'ObservableSource'
            ObservableSource output1 = instance.Output;
            output1.ObservableStr.Subscribe(Console.WriteLine);

            // using generic type 'ObservableSource<T>'
            ObservableOutput<string> output2 = instance.Output as ObservableOutput<string>;
            output2.Observable.Subscribe(Console.WriteLine);
            
            instance["a"].OnNext2("one");    // using non-generic type 'ObservableInput'
            (instance["a"] as ObservableInput<string>).OnNext2("two"); // using generic type
            instance["b"].OnNext2("tree");
            instance["a"].OnCompleted2();
            instance["b"].OnCompleted2();
            instance["c"].OnCompleted2();

            Console.WriteLine(XmlSerializationHelper.ToXml(instance.Diagram ));
        }


   
    }
}
