﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reactive.Linq;
using NUnit.Framework;
using System.Threading;
using System.Diagnostics;

namespace RxSandbox.Tests
{
    [TestFixture]
    public class MiscTests
    {

           

        // http://blogs.msdn.com/b/jeffva/archive/2010/07/26/rx-on-the-server-part-2-of-n-asynchronous-streamreader.aspx         
        //The Rx contract requires IObservable implementations to fire messages in a serialized fashion. When encountering 
        // an IObservable implementation that does not follow this rule, the .Synchronize operator will fix the bad behaving
        // object.


        //[Test]
        //public void SerializedFashionTest()
        //{
        //    Observable.
        //        .Interval(TimeSpan.FromSeconds(1), System.Reactive.Concurrency.Scheduler.NewThread)
        //        .Take(3)
        //        .Run( l =>
        //                  {
        //                      Console.WriteLine("start - " + l);
        //                      Thread.Sleep(1000 * (5-(int)l));
        //                      Console.WriteLine("end - " + l);
        //                  });     
        //}

        [Test]
        public void DiagramSerialization()
        {
            var diagram1 = new Diagram()
              {
                  Id = "Zip",
                  Inputs =
                      {
                          new Series
                              {
                                  Name = "a",
                                  //TypeName = "System.String",
                                  Marbles =
                                      {
                                          new Marble {Value = "one", Order = 1},
                                          new Marble {Value = "two", Order = 3},
                                          new Marble {Value = "tree", Order = 4},
                                      }

                              },
                        new Series
                              {
                                  Name = "b",
                                  //TypeName = "System.String",
                                  Marbles =
                                      {
                                          new Marble {Value = "1", Order = 2},
                                      }
                              }
                      }
                      ,
                  Output = new Series
                  {
                      Name = "a.Zip(b, (x,y) => x + y)",
                      //TypeName = "System.String",
                      Marbles =
                                      {
                                          new Marble {Value = "one1", Order = 2},
                                      }
                  }

              };



            var s1 = XmlSerializationHelper.ToXml(diagram1);
            var diagram2 = XmlSerializationHelper.FromXml<Diagram>(s1);
            var s2 = XmlSerializationHelper.ToXml(diagram2);
            Assert.AreEqual(s1, s2);

            Console.WriteLine(s1);
        }

        [Test]
        public void DrawingDiagramTest()
        {
            Expression<Func<IObservable<string>, IObservable<string>,
                IObservable<string>>> expression
                    = (a, b) => a.Zip(b, (x, y) => x + " - " + y);

            var definition = ExpressionDefinition.Create(expression);            
            var viewModel = new ExpressionInstanceVM(definition);


            var aGeneratorVM = viewModel.Inputs.First(g => g.Name == "a");
            var bGeneratorVM = viewModel.Inputs.First(g => g.Name == "b");

            aGeneratorVM.Value = "one";
            aGeneratorVM.OnNext.Execute(null); Thread.Sleep(1000);
            aGeneratorVM.Value = "two";
            aGeneratorVM.OnNext.Execute(null); Thread.Sleep(1000);

            bGeneratorVM.Value = "1";
            bGeneratorVM.OnNext.Execute(null); Thread.Sleep(1000);
            bGeneratorVM.Value = "2";
            bGeneratorVM.OnNext.Execute(null); Thread.Sleep(1000);
            bGeneratorVM.Value = "3";
            bGeneratorVM.OnNext.Execute(null); Thread.Sleep(1000);
            bGeneratorVM.OnCompleted.Execute(null); Thread.Sleep(1000);

            aGeneratorVM.Value = "tree";
            aGeneratorVM.OnNext.Execute(null); Thread.Sleep(1000);
            aGeneratorVM.Value = "four";
            aGeneratorVM.OnNext.Execute(null); Thread.Sleep(1000);
            aGeneratorVM.OnCompleted.Execute(null); Thread.Sleep(1000);

            Console.WriteLine(XmlSerializationHelper.ToXml(viewModel.Diagram));

            //Exception onErrorException = null;
            //var aGenerator = new Generator<string>();
            //aGenerator.ObservableStr.Subscribe((a) => { }, (ex) => onErrorException = ex);

            //(aGenerator as Generator).OnNext("yo1");
            //(aGenerator as Generator).OnNext("yo2");
            //var exception = new Exception();
            //(aGenerator).OnError(exception);

            //Assert.IsFalse(aGenerator.IsActive);
            //Assert.IsNotNull(onErrorException);
            //Assert.AreSame(exception, onErrorException);
        }




        [Test]
        public void PrintAllTestedOperators()
        {
            var operators = typeof (StandardOperators)
                .GetMethods()
                .Where(m => m.DeclaringType == typeof (StandardOperators))
                .Select((m, i) => i + "." + m.Name);

            foreach (var @operator in operators)
            {
                Console.WriteLine(@operator);
            }            
        }


    }
}
